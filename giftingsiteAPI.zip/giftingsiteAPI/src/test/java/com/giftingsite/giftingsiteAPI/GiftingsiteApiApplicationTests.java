package com.giftingsite.giftingsiteAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiftingsiteApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
