package com.example.gifting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiftingApplicationTests {

	@Test
	void contextLoads() {
	}

}
