package com.example.gifting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftingApplication.class, args);
	}

}
